#include "mainwindow.h"

#include <QApplication>
#include <KLocalizedString>

#ifndef APP_ID
#define APP_ID "org.evernight.vista.grubconfig"
#endif

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    KLocalizedString::setApplicationDomain("evernight-vista-grub-config");

    app.setApplicationName(QStringLiteral("evernight-vista-grub-config"));
    app.setApplicationDisplayName(i18n("Evernight Vista GRUB Config"));
    app.setOrganizationName(QStringLiteral("Evernight Vista"));
    app.setDesktopFileName(QStringLiteral(APP_ID));

    MainWindow window;
    window.show();

    return app.exec();
}
