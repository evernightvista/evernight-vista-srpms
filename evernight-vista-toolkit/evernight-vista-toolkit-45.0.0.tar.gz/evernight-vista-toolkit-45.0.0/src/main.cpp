#include "mainwindow.h"

#include <KAboutData>
#include <KLocalizedString>

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    KLocalizedString::setApplicationDomain("evernight-vista-toolkit");

    KAboutData aboutData(QStringLiteral("evernight-vista-toolkit"),
                         i18n("Evernight Vista Toolkit"),
                         QStringLiteral("0.1.0"),
                         i18n("Evernight Vista system utility toolkit"),
                         KAboutLicense::GPL_V3,
                         i18n("(c) 2026 Evernight Vista"));
    aboutData.setDesktopFileName(QStringLiteral("evernight-vista-toolkit"));
    KAboutData::setApplicationData(aboutData);

    MainWindow window;
    window.show();
    return app.exec();
}
