// SPDX-FileCopyrightText: 2025 Carl Schwan <carl@carlschwan.eu>
// SPDX-FileCopyrightText: 2025 Kristen McWilliam <kristen@kde.org>
// SPDX-FileCopyrightText: 2026 Jesús T. <hello.triplean.dev@gmail.com>
// SPDX-FileCopyrightText: 2026 Tiziano Gaia <ti.gaia@proton.me>
//
// SPDX-License-Identifier: LGPL-2.0-or-later

import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

import org.kde.kirigami as Kirigami
import org.kde.kirigamiaddons.components as KirigamiComponents

import org.kde.plasmasetup
import org.kde.plasmasetup.components as PlasmaSetupComponents

PlasmaSetupComponents.SetupModule {
    id: root

    available: !AccountController.hasExistingUsers

    /*!
    Whether the entered username is valid.
    */
    property bool usernameValid: AccountController.isUsernameValid(usernameField.text)

    /*!
    Message describing why the username is invalid, or empty if valid.
    */
    property string usernameValidationMessage: AccountController.usernameValidationMessage(usernameField.text)

    nextEnabled: root.usernameValid && passwordField.text.length > 0 && repeatField.text === passwordField.text

    function onPageActivated() {
        fullNameField.forceActiveFocus();
    }

    function ensureVisible(item: Item): void {
        const flickable = scroll.contentItem;
        const itemPos = item.mapToItem(flickable.contentItem, 0, 0);
        const margin = Kirigami.Units.gridUnit;

        const itemTop = itemPos.y;
        const itemBottom = itemPos.y + item.height;
        const visibleTop = flickable.contentY;
        const visibleBottom = visibleTop + flickable.height;

        if (itemTop < visibleTop + margin) {
            flickable.contentY = Math.max(0, itemTop - margin);
        } else if (itemBottom > visibleBottom - margin) {
            flickable.contentY = itemBottom - flickable.height + margin;
        }
    }

    contentItem: ScrollView {
        id: scroll
        clip: true

        ColumnLayout {
            id: mainColumn
            width: scroll.availableWidth

            Item { Layout.fillHeight: true }

            ColumnLayout {
                Layout.alignment: Qt.AlignHCenter
                Layout.fillWidth: true
                Layout.maximumWidth: root.cardWidth

                KirigamiComponents.AvatarButton {
                    id: avatar

                    Layout.alignment: Qt.AlignHCenter | Qt.AlignVCenter

                    // Square button
                    implicitWidth: Kirigami.Units.gridUnit * 5
                    implicitHeight: implicitWidth

                    name: fullNameField.text

                    // Disabled so it doesn't act like a button, instead we use it
                    // as a simple avatar with user initial for now.
                    //
                    // TODO: Implement avatar selection
                    enabled: false
                }

                // Padding around the text
                Item {
                    Layout.topMargin: Kirigami.Units.gridUnit
                }

                Label {
                    wrapMode: Text.Wrap
                    horizontalAlignment: Text.AlignHCenter
                    text: i18n("We need a few details to complete the setup.")

                    Layout.leftMargin: Kirigami.Units.gridUnit
                    Layout.rightMargin: Kirigami.Units.gridUnit
                    Layout.fillWidth: true
                }

                Item {
                    Layout.fillWidth: true
                    implicitHeight: Math.max(administratorLabel.implicitHeight, helpButton.implicitHeight)

                    Label {
                        id: administratorLabel

                        anchors.horizontalCenter: parent.horizontalCenter
                        width: Math.min(
                            implicitWidth,
                            root.cardWidth - helpButton.implicitWidth - Kirigami.Units.largeSpacing
                        )

                        text: i18nc("@info", "This user will be an administrator.")
                        horizontalAlignment: Text.AlignHCenter
                        wrapMode: Text.Wrap
                    }

                    Kirigami.ContextualHelpButton {
                        id: helpButton

                        anchors.left: administratorLabel.right
                        anchors.verticalCenter: administratorLabel.verticalCenter

                        toolTipText: xi18nc("@info", "This user will have administrative privileges on the system.<nl/><nl/>This means that they can change system settings, install software, and access all files on the system.<nl/><nl/>Choose a strong password for this user.")
                    }
                }

                // Padding around the text
                Item {
                    Layout.bottomMargin: Kirigami.Units.gridUnit
                }

                Kirigami.FormLayout {
                    Layout.fillWidth: true

                    TextField {
                        id: fullNameField

                        Kirigami.FormData.label: i18nc("@label:textbox", "Full Name")

                        onActiveFocusChanged: {
                            if (activeFocus) {
                                Qt.callLater(() => root.ensureVisible(fullNameField));
                            }
                        }

                        property string previousText: ''
                        onTextChanged: {
                            if (usernameField.text.length === 0 || usernameField.text === previousText) {
                                usernameField.text = previousText = AccountController.sanitizeUsername(fullNameField.text)
                            }
                        }

                        Binding {
                            target: AccountController
                            property: 'fullName'
                            value: fullNameField.text
                        }
                    }

                    TextField {
                        id: usernameField

                        Kirigami.FormData.label: i18nc("@label:textbox", "Username")

                        onActiveFocusChanged: {
                            if (activeFocus) {
                                Qt.callLater(() => root.ensureVisible(usernameField));
                            }
                        }

                        inputMethodHints: Qt.ImhNoAutoUppercase | Qt.ImhNoPredictiveText

                        Binding {
                            target: AccountController
                            property: 'username'
                            value: usernameField.text
                        }
                    }

                    Kirigami.InlineMessage {
                        Layout.fillWidth: true
                        type: Kirigami.MessageType.Error
                        text: root.usernameValidationMessage
                        visible: root.usernameValidationMessage.length > 0 && usernameField.text.length > 0
                    }

                    Kirigami.PasswordField {
                        id: passwordField

                        Kirigami.FormData.label: i18nc("@label:textbox", "Password")

                        onActiveFocusChanged: {
                            if (activeFocus) {
                                Qt.callLater(() => root.ensureVisible(passwordField));
                            }
                        }

                        placeholderText: "" // Form label already indicates this
                        onTextChanged: debouncer.reset()

                        Binding {
                            target: AccountController
                            property: 'password'
                            value: passwordField.text
                        }
                    }

                    Kirigami.PasswordField {
                        id: repeatField

                        Kirigami.FormData.label: i18nc("@label:textbox", "Confirm Password")

                        onActiveFocusChanged: {
                            if (activeFocus) {
                                Qt.callLater(() => root.ensureVisible(repeatField));
                            }
                        }

                        placeholderText: "" // Form label already indicates this

                        onAccepted: {
                            if (root.nextEnabled) {
                                root.nextRequested();
                            }
                        }

                        onTextChanged: debouncer.reset()

                        onEditingFinished: {
                            debouncer.isTriggered = true;
                        }
                    }

                    PlasmaSetupComponents.Debouncer {
                        id: debouncer
                    }

                    Kirigami.InlineMessage {
                        id: passwordWarning

                        Layout.fillWidth: true
                        type: Kirigami.MessageType.Error
                        text: i18n("Passwords must match")
                        visible: passwordField.text !== "" && repeatField.text !== "" && passwordField.text !== repeatField.text && debouncer.isTriggered
                    }
                }
            }

            Item { Layout.fillHeight: true }
        }
    }
}
